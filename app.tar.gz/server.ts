import express from 'express';
import helmet from 'helmet';
import {rateLimit} from 'express-rate-limit';
import {fileURLToPath} from 'node:url';
import {resolve} from 'node:path';
import {openStore} from './lib/store';
import {random,hash,same,Locks} from './lib/security';
import {googleService,scope} from './lib/google';
import {runtime} from './lib/runtime';
import * as transactions from './app/api/transactions/route';
import * as debts from './app/api/debts/route';
import * as assets from './app/api/assets/route';
export function createApp(env:NodeJS.ProcessEnv=process.env){
 const origin=new URL(env.APP_ORIGIN||'http://localhost:3000').origin;
 const secure=origin.startsWith('https:');
 if(!secure&&!['localhost','127.0.0.1'].includes(new URL(origin).hostname))throw Error('APP_ORIGIN must use HTTPS');
 const config={origin,clientId:env.GOOGLE_CLIENT_ID||'',clientSecret:env.GOOGLE_CLIENT_SECRET||'',tokenKey:env.TOKEN_KEY||''};
 const configured=!!(config.clientId&&config.clientSecret&&config.tokenKey);
 const db=openStore(env.DATABASE_PATH||'./data/app.sqlite'),locks=new Locks();
 const google=configured?googleService(config,db):null,app=express();
 app.disable('x-powered-by');if(env.TRUST_PROXY==='1')app.set('trust proxy',1);
 app.use(helmet({contentSecurityPolicy:{directives:{defaultSrc:["'self'"],scriptSrc:["'self'"],styleSrc:["'self'","'unsafe-inline'"],imgSrc:["'self'","data:"],connectSrc:["'self'"],frameAncestors:["'none'"],formAction:["'self'"],...(secure?{}:{upgradeInsecureRequests:null})}},strictTransportSecurity:secure?undefined:false}));
 app.use((_req,res,next)=>{res.set('Cache-Control','private, no-store');next()});
 const cookieName=secure?'__Host-finance':'finance_dev',oauthCookie=secure?'__Host-finance-oauth':'finance_oauth_dev';
 const options={httpOnly:true,secure,sameSite:'lax' as const,path:'/'};
 const cookies=(req:express.Request)=>Object.fromEntries((req.headers.cookie||'').split(';').map(x=>x.trim().split('=')));
 function user(req:express.Request){const id=cookies(req)[cookieName];if(!id)return null;return db.prepare('SELECT u.* FROM users u JOIN sessions s ON s.sub=u.sub WHERE s.id=? AND s.expires>?').get(hash(id),Date.now()) as any}
 const denied=(res:express.Response)=>res.status(401).json({status:'reauthentication_required',message:'Đăng nhập Google để mở sổ riêng.',chatGPTSignInPath:'/auth/google'});
 const csrf=(req:express.Request,res:express.Response,next:express.NextFunction)=>req.get('origin')===origin?next():res.status(403).json({status:'forbidden',message:'Nguồn yêu cầu không hợp lệ.'});
 app.get('/healthz',(_req,res)=>res.json({ok:true}));
 app.get('/api/me',(req,res)=>{const u=user(req);res.json({configured,user:u?{email:u.email,book:u.ready?u.book:null,sessionKey:hash(cookies(req)[cookieName]||'')}:null})});
 app.use('/auth',rateLimit({windowMs:60000,limit:30,standardHeaders:'draft-8',legacyHeaders:false}));
 app.get('/auth/google',async(req,res)=>{
 if(!google)return res.redirect('/?auth=setup');
 const state=random(),nonce=random(),browser=random(),auth=await google.authorization(state,nonce);
 db.prepare('DELETE FROM oauth WHERE expires<?').run(Date.now());db.prepare('DELETE FROM sessions WHERE expires<?').run(Date.now());
 db.prepare('INSERT INTO oauth VALUES(?,?,?,?,?)').run(hash(state),nonce,auth.verifier,hash(browser),Date.now()+600000);
 res.cookie(oauthCookie,browser,{...options,maxAge:600000});res.redirect(auth.url);
 });
 app.get('/auth/google/callback',async(req,res)=>{
 res.clearCookie(oauthCookie,options);if(!google)return res.redirect('/?auth=setup');
 const state=typeof req.query.state==='string'?req.query.state:'',row=db.prepare('SELECT * FROM oauth WHERE state=?').get(hash(state)) as any;
 if(!row||row.expires<Date.now()||!same(row.browser,hash(cookies(req)[oauthCookie]||'')))return res.status(400).send('Phiên đăng nhập không hợp lệ hoặc hết hạn. Quay lại trang chủ để thử lại.');
 db.prepare('DELETE FROM oauth WHERE state=?').run(hash(state));
 if(req.query.error)return res.redirect('/?auth=cancelled');
 try{const code=typeof req.query.code==='string'?req.query.code:'';if(!code)throw Error();
 const c=google.client(),{tokens}=await c.getToken({code,codeVerifier:row.verifier});if(!tokens.id_token)throw Error();
 const ticket=await c.verifyIdToken({idToken:tokens.id_token,audience:config.clientId}),p=ticket.getPayload();
 if(!p?.sub||!p.email||!p.email_verified||!same(p.nonce||'',row.nonce)||!(tokens.scope||'').split(' ').includes(scope))throw Error();
 await locks.run(p.sub,async()=>{const old=db.prepare('SELECT tokens FROM users WHERE sub=?').get(p.sub) as any;const prior=old?google.box.open(old.tokens,p.sub):{};const merged={...prior,...tokens};if(!merged.refresh_token)throw Error();
 db.prepare('INSERT INTO users(sub,email,tokens) VALUES(?,?,?) ON CONFLICT(sub) DO UPDATE SET email=excluded.email,tokens=excluded.tokens').run(p.sub,p.email!,google.box.seal(merged,p.sub));});
 const oldSession=cookies(req)[cookieName];if(oldSession)db.prepare('DELETE FROM sessions WHERE id=?').run(hash(oldSession));
 const session=random();db.prepare('INSERT INTO sessions VALUES(?,?,?)').run(hash(session),p.sub,Date.now()+14*86400000);
 res.cookie(cookieName,session,{...options,maxAge:14*86400000});res.redirect('/');
 }catch{res.redirect('/?auth=failed')}
 });
 app.post('/auth/logout',csrf,(req,res)=>{db.prepare('DELETE FROM sessions WHERE id=?').run(hash(cookies(req)[cookieName]||''));res.clearCookie(cookieName,options);res.redirect('/')});
 // The request-scoped OAuth client never receives a user/file ID from browser input.
 async function googleRequest(sub:string){const client=await google!.userClient(sub);return async(url:string,method='GET',data?:unknown)=>{const r=await client.request({url,method:method as any,data,retry:false,timeout:25000});return r.data}}
 const accountGuard=(req:express.Request,res:express.Response,next:express.NextFunction)=>{const u=user(req);if(!u)return denied(res);if(!same(req.get('x-session-key')||'',hash(cookies(req)[cookieName]||'')))return res.status(409).json({status:'account_changed',message:'Tài khoản đã thay đổi ở tab khác. Tải lại trang trước khi tiếp tục.'});next()};
 app.use('/api/workbook',accountGuard);
 app.use(['/api/transactions','/api/debts','/api/assets'],accountGuard);
 app.post('/api/workbook',csrf,rateLimit({windowMs:60000,limit:10}),async(req,res)=>{
 const u=user(req);if(!u||!google)return denied(res);
 try{const book=await locks.run(u.sub,async()=>google.ensureBook(u.sub,await googleRequest(u.sub)));res.json({status:'success',book})}catch(e:any){res.status(409).json({status:'setup_failed',message:e.response?'Không xác nhận được thao tác Google. Kiểm tra quyền Drive rồi thử lại.':e.message})}
 });
 app.post('/auth/disconnect',csrf,async(req,res)=>{const u=user(req);if(!u||!google)return denied(res);
 await locks.run(u.sub,async()=>{const c=await google.userClient(u.sub);try{await c.revokeCredentials()}catch{res.status(502).send('Chưa thu hồi được quyền Google. Có thể thu hồi tại trang Quyền truy cập tài khoản Google.');return}
 db.prepare('DELETE FROM sessions WHERE sub=?').run(u.sub);db.prepare('DELETE FROM users WHERE sub=?').run(u.sub);res.clearCookie(cookieName,options);res.redirect('/')})});
 app.use('/api',rateLimit({windowMs:60000,limit:120,standardHeaders:'draft-8',legacyHeaders:false}));
 app.use('/api',express.text({type:'application/json',limit:'120kb'}));
 for(const [name,handler] of Object.entries({transactions,debts,assets})){
 app.all('/api/'+name,async(req,res)=>{
 if(!['GET','POST'].includes(req.method))return res.sendStatus(405);
 if(req.method==='POST'&&req.get('origin')!==origin)return res.sendStatus(403);
 const u=user(req);if(!u||!google)return denied(res);
 if(!u.ready||!u.book)return res.status(409).json({status:'setup_required',message:'Bấm Mở sổ trong Google Drive trước.'});
 const execute=async()=>{const request=new Request(origin+req.originalUrl,{method:req.method,headers:{origin:req.get('origin')||'','Content-Type':'application/json'},...(req.method==='POST'?{body:typeof req.body==='string'?req.body:''}:{})});
 const result=await runtime.run({sub:u.sub,email:u.email,book:u.book,google:await googleRequest(u.sub)},()=>req.method==='POST'?handler.POST(request):(handler.GET as (req:Request)=>Promise<Response>)(request));
 res.status(result.status);result.headers.forEach((v,k)=>res.set(k,v));res.send(await result.text());};
 try{if(req.method==='POST')await locks.run(u.sub,execute);else await execute()}catch{res.status(502).json({status:'upstream_error',message:'Không xác nhận được thao tác. Làm mới để kiểm tra.'})}
 })}
 const publicDir=fileURLToPath(new URL('./public',import.meta.url));
 app.use(express.static(publicDir,{etag:false,lastModified:false}));
 app.use((_req,res)=>res.sendStatus(404));
 app.use((_err:unknown,_req:express.Request,res:express.Response,_next:express.NextFunction)=>res.status(500).json({status:'server_error',message:'Không xử lý được yêu cầu. Thử lại sau.'}));
 return {app,db};
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){const {app}=createApp();app.listen(Number(process.env.PORT||3000),'0.0.0.0',()=>console.log('Finance app listening'))}
