import {workbookId} from '@/lib/runtime';
import {connectorsForRequest,type Json} from '@/lib/connectors';
import {connectorResponse} from '@/lib/connector-errors.mjs';
import {getGoogleUser,googleSignInPath} from '@/app/google-auth';
import {identifier,serialDate,readDate} from '@/lib/debts';
import {assetKind,configs,parseAsset,calculated,type Kind} from '@/lib/assets';
import {z} from 'zod';
export const dynamic='force-dynamic';
const C='google';
const reply=(body:unknown,status=200)=>Response.json(body,{status,headers:{'Cache-Control':'private, no-store'}});
async function failure(r:any,kind:Kind){const response=connectorResponse(r),body:any=await response.json();if(body.status==='reauthentication_required')body.chatGPTSignInPath=googleSignInPath('/#'+kind);return reply(body,response.status)}
function payload(r:any):any{if(r?.structuredContent!==undefined)return r.structuredContent?.structuredContent??r.structuredContent;for(const c of r?.content||[])if(c.type==='text'){try{return JSON.parse(c.text)}catch{}}return null}
async function read(kind:Kind,api:ReturnType<typeof connectorsForRequest>){const c=configs[kind];
 const result=await api.invoke(C,'get_spreadsheet_range',{spreadsheet_id:workbookId(),sheet_name:"'"+c.title+"'",range:`A1:${kind==='savings'?'O':'L'}2001`,value_render_option:'UNFORMATTED_VALUE'});
 if(result.status!=='success')return {error:await failure(result,kind)};
 const values=payload(result.result)?.values;
 if(!Array.isArray(values)||c.headers.some((h,i)=>values[0]?.[i]!==h))return {error:reply({status:'invalid_sheet',message:'Tiêu đề trang '+c.title+' không đúng. Giữ nguyên tên các cột.'},409)};
 const rows:any[]=[],ids=new Set();
 for(let i=1;i<values.length;i++){const r=values[i];if(!r.some((v:any)=>v!==''&&v!==null))continue;
 try{const obj=Object.fromEntries(c.keys.map((key,j)=>[key,c.dates.includes(j)?readDate(r[j]||''):key==='value'&&(r[j]===''||r[j]==null)?null:r[j]??'']));const entry=parseAsset(kind,obj);const n=c.headers.length;
 if(ids.has(entry.id)||!['Đang dùng','Đã xóa'].includes(r[n-2]))throw Error();ids.add(entry.id);
 rows.push({...entry,calc:calculated(kind,entry),deleted:r[n-2]==='Đã xóa',op:r[n-1],row:i,base:JSON.stringify(r)});
 }catch{return {error:reply({status:'invalid_sheet',message:`Dòng ${i+1} trong ${c.title} không hợp lệ. Kiểm tra lại dữ liệu.`},409)}}}
 return {rows,result:result.result,full:values.length>=2001};
}
export async function GET(req:Request){const kind=assetKind.safeParse(new URL(req.url).searchParams.get('kind'));if(!kind.success)return reply({status:'invalid_request'},400);try{const r=await read(kind.data,connectorsForRequest());return r.error??reply({status:'success',rows:r.rows!.filter(x=>!x.deleted),result:r.result})}catch{return reply({status:'upstream_error',message:'Không tải được dữ liệu. Các số đang hiển thị có thể đã cũ.'},502)}}
const inputSchema=z.object({kind:assetKind,action:z.enum(['create','update','delete']),id:identifier,op:identifier,base:z.string().max(20000).optional(),entry:z.unknown().optional()}).strict();
export async function POST(req:Request){
 if(req.headers.get('origin')!==new URL(req.url).origin)return reply({status:'forbidden'},403);
 if(!await getGoogleUser())return reply({status:'reauthentication_required',message:'Đăng nhập để lưu.',chatGPTSignInPath:googleSignInPath('/')},401);
 let input:z.infer<typeof inputSchema>,entry:any;
 try{const text=await req.text();if(text.length>30000)throw Error();input=inputSchema.parse(JSON.parse(text));if(input.action!=='delete'){entry=parseAsset(input.kind,input.entry);if(entry.id!==input.id)throw Error();}}catch{return reply({status:'invalid_request',message:'Kiểm tra tên, số tiền, lãi suất và ngày tháng.'},400)}
 try{const api=connectorsForRequest(),r=await read(input.kind,api);if(r.error)return r.error;const previous=r.rows!.find(x=>x.id===input.id);
 if(previous?.op===input.op)return reply({status:'success',result:r.result});
 if(input.action==='create'&&previous||input.action!=='create'&&(!previous||previous.deleted||previous.base!==input.base))return reply({status:'conflict',message:'Dữ liệu đã thay đổi. Bấm Làm mới và mở lại khoản này.'},409);
 if(input.action==='create'&&r.full)return reply({status:'capacity_reached',message:'Trang đã đạt giới hạn 2.000 dòng.'},409);
 const c=configs[input.kind];if(input.action==='delete')entry=Object.fromEntries(c.keys.map(k=>[k,previous[k]]));
 const calc:any=calculated(input.kind,entry),raw:any[]=c.keys.map(k=>entry[k]??'');
 raw.push(...(input.kind==='savings'?[calc.days,calc.interest,calc.total]:[calc?.gain??'']),new Date().toISOString(),input.action==='delete'?'Đã xóa':'Đang dùng',input.op);
 const values=raw.map((v,i)=>{const value=c.dates.includes(i)?serialDate(v):v;return {userEnteredValue:typeof value==='number'?{numberValue:value}:{stringValue:String(value)},userEnteredFormat:{textFormat:{fontFamily:'Arial',fontSize:11},...(c.dates.includes(i)?{numberFormat:{type:'DATE',pattern:'dd/mm/yyyy'}}:c.numbers.includes(i)?{numberFormat:{type:'NUMBER',pattern:i===3&&input.kind==='savings'?'0.####':'#,##0'}}:{})}}});
 const rows=[{values}],request=previous?{updateCells:{start:{sheetId:c.sheet,rowIndex:previous.row,columnIndex:0},rows,fields:'userEnteredValue,userEnteredFormat'}}:{appendCells:{sheetId:c.sheet,rows,fields:'userEnteredValue,userEnteredFormat'}};
 const result=await api.invoke(C,'batch_update_spreadsheet',{spreadsheet_id:workbookId(),requests:[request as unknown as Json],include_spreadsheet_in_response:false});return result.status==='success'?reply({status:'success',result:result.result}):failure(result,input.kind);
 }catch{return reply({status:'upstream_error',message:'Chưa xác nhận được việc lưu. Làm mới để kiểm tra trước khi gửi lại.'},502)}
}
