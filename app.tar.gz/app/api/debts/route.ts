import {workbookId} from '@/lib/runtime';
import {connectorsForRequest,type Json} from '@/lib/connectors';
import {connectorResponse} from '@/lib/connector-errors.mjs';
import {getGoogleUser,googleSignInPath} from '@/app/google-auth';
import {z} from 'zod';
import {debtHeaders,debtInput,paymentInput,identifier,paidTotal,checkPayment,serialDate,readDate} from '@/lib/debts';
export const dynamic='force-dynamic';
const C='google',SHEET=1;
const common={op:identifier,base:z.string().max(100000).optional()};
const requestSchema=z.discriminatedUnion('action',[
 z.object({...common,action:z.literal('create'),entry:debtInput}).strict(),
 z.object({...common,action:z.literal('update'),entry:debtInput}).strict(),
 z.object({...common,action:z.literal('delete'),id:identifier}).strict(),
 z.object({...common,action:z.literal('repay'),id:identifier,payment:paymentInput}).strict(),
]);
const reply=(body:unknown,status=200)=>Response.json(body,{status,headers:{'Cache-Control':'private, no-store'}});
async function failure(result:any){const response=connectorResponse(result),body:any=await response.json();if(body.status==='reauthentication_required')body.chatGPTSignInPath=googleSignInPath('/#loans');return reply(body,response.status);}
function payload(result:any):any{if(result?.structuredContent!==undefined)return result.structuredContent?.structuredContent??result.structuredContent;for(const c of result?.content||[])if(c.type==='text'){try{return JSON.parse(c.text)}catch{}}return null;}
async function read(api:ReturnType<typeof connectorsForRequest>){
 const response=await api.invoke(C,'get_spreadsheet_range',{spreadsheet_id:workbookId(),sheet_name:"'Vay và cho vay'",range:'A1:M5001',value_render_option:'UNFORMATTED_VALUE'});
 if(response.status!=='success')return {error:await failure(response)};
 const values=payload(response.result)?.values;
 if(!Array.isArray(values)||debtHeaders.some((h,i)=>values[0]?.[i]!==h))return {error:reply({status:'invalid_sheet',message:'Cấu trúc trang Vay và cho vay đã thay đổi. Hãy giữ nguyên các tiêu đề cột.'},409)};
 if(values.length>=5001)return {error:reply({status:'capacity_reached',message:'Trang vay đã đạt giới hạn 5.000 dòng.'},409)};
 const rows:any[]=[],ids=new Set();
 for(let i=1;i<values.length;i++){
  const r=values[i];if(!r.some((v:any)=>v!==''&&v!==null))continue;
  try{
   const entry=debtInput.parse({id:r[0],type:r[1]==='Đi vay'?'borrow':r[1]==='Cho vay'?'lend':'invalid',person:r[2],amount:r[3],date:readDate(r[4]),due:readDate(r[5]||''),note:r[6]||''});
   const payments=z.array(paymentInput).max(100).parse(JSON.parse(r[9]||'[]'));
   const paid=paidTotal(payments);
   if(ids.has(entry.id)||paid>entry.amount||r[7]!==paid||r[8]!==entry.amount-paid||!['Đang dùng','Đã xóa'].includes(r[11])||new Set(payments.map(p=>p.id)).size!==payments.length||payments.some(p=>p.date<entry.date))throw Error();
   ids.add(entry.id);rows.push({...entry,payments,paid,remaining:entry.amount-paid,deleted:r[11]==='Đã xóa',updated:r[10],op:r[12],row:i,base:JSON.stringify(r)});
  }catch{return {error:reply({status:'invalid_sheet',message:`Dòng ${i+1} trong trang vay không hợp lệ. Hãy kiểm tra dữ liệu trước khi tiếp tục.`},409)}}
 }
 return {rows,result:response.result};
}
export async function GET(){try{const r=await read(connectorsForRequest());return r.error??reply({status:'success',rows:r.rows!.filter(d=>!d.deleted),result:r.result});}catch{return reply({status:'upstream_error',message:'Không tải được khoản vay. Hãy làm mới; dữ liệu hiện có có thể đã cũ.'},502)}}
export async function POST(req:Request){
 if(req.headers.get('origin')!==new URL(req.url).origin)return reply({status:'forbidden',message:'Nguồn yêu cầu không hợp lệ.'},403);
 if(!await getGoogleUser())return reply({status:'reauthentication_required',message:'Đăng nhập Google để lưu khoản vay.',chatGPTSignInPath:googleSignInPath('/#loans')},401);
 let input:z.infer<typeof requestSchema>;try{const raw=await req.text();if(raw.length>110000)throw Error();input=requestSchema.parse(JSON.parse(raw));}catch{return reply({status:'invalid_request',message:'Kiểm tra số tiền, người liên quan và ngày tháng. Hạn trả không được trước ngày vay.'},400)}
 try{
  const api=connectorsForRequest(),state=await read(api);if(state.error)return state.error;
  const id='entry' in input?input.entry.id:input.id,previous=state.rows!.find(d=>d.id===id);
  if(previous?.op===input.op||input.action==='repay'&&previous?.payments.some((p:any)=>p.id===input.payment.id))return reply({status:'success',result:state.result});
  if(input.action==='create'&&previous||input.action!=='create'&&(!previous||previous.deleted||previous.base!==input.base))return reply({status:'conflict',message:'Khoản vay đã thay đổi hoặc đã tồn tại. Làm mới rồi mở lại khoản vay.'},409);
  const entry='entry' in input?input.entry:debtInput.parse(Object.fromEntries(['id','type','person','amount','date','due','note'].map(k=>[k,previous[k]])));
  const payments=[...(previous?.payments||[])];
  if(input.action==='repay'){try{checkPayment(entry,payments,input.payment)}catch(e){return reply({status:'invalid_request',message:(e as Error).message},400)}payments.push(input.payment);}
  const paid=paidTotal(payments);
  if(entry.amount<paid||payments.some(p=>p.date<entry.date))return reply({status:'invalid_request',message:'Số tiền gốc hoặc ngày vay mâu thuẫn với lịch sử trả nợ.'},400);
  const values=[entry.id,entry.type==='borrow'?'Đi vay':'Cho vay',entry.person,entry.amount,serialDate(entry.date),serialDate(entry.due),entry.note,paid,entry.amount-paid,JSON.stringify(payments),new Date().toISOString(),input.action==='delete'?'Đã xóa':'Đang dùng',input.op].map((v,i)=>({userEnteredValue:typeof v==='number'?{numberValue:v}:{stringValue:v},userEnteredFormat:{textFormat:{fontFamily:'Arial',fontSize:11},...([3,7,8].includes(i)?{numberFormat:{type:'NUMBER',pattern:'#,##0'}}:[4,5].includes(i)?{numberFormat:{type:'DATE',pattern:'dd/mm/yyyy'}}:{})}}));
  const rows=[{values}],request=previous?{updateCells:{start:{sheetId:SHEET,rowIndex:previous.row,columnIndex:0},rows,fields:'userEnteredValue,userEnteredFormat'}}:{appendCells:{sheetId:SHEET,rows,fields:'userEnteredValue,userEnteredFormat'}};
  const result=await api.invoke(C,'batch_update_spreadsheet',{spreadsheet_id:workbookId(),requests:[request as unknown as Json],include_spreadsheet_in_response:false});
  return result.status==='success'?reply({status:'success',result:result.result}):failure(result);
 }catch{return reply({status:'upstream_error',message:'Chưa xác nhận được thao tác. Làm mới để kiểm tra trước khi gửi lại.'},502)}
}
