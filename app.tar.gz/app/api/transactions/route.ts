import {workbookId} from '@/lib/runtime';
import { connectorsForRequest, type Json } from '@/lib/connectors';
import { connectorResponse } from '@/lib/connector-errors.mjs';
import { getGoogleUser, googleSignInPath } from '@/app/google-auth';
import { z } from 'zod';

export const dynamic = 'force-dynamic';
const CONNECTOR='google';

const SHEET=0;
const HEADER=['Mã giao dịch','Ngày','Loại','Danh mục','Số tiền (VND)','Ví','Ghi chú','Cập nhật','Trạng thái','Mã thao tác'];
const id=z.string().regex(/^[a-zA-Z0-9-]{16,64}$/);
const entry=z.object({id,type:z.enum(['income','expense']),date:z.string().regex(/^\d{4}-\d{2}-\d{2}$/).refine(s=>{const d=new Date(s);return !isNaN(+d)&&d.toISOString().slice(0,10)===s}),category:z.string().min(1).max(60),amount:z.number().int().positive().max(999999999999),wallet:z.enum(['Tiền mặt','Ngân hàng','Ví điện tử']),note:z.string().max(180)}).strict();
const write=z.object({action:z.enum(['create','update','delete']),op:id,entry,base:z.string().max(100).optional()}).strict();
function reply(body:unknown,status=200){return Response.json(body,{status,headers:{'Cache-Control':'private, no-store'}})}
function payload(result:any):any{
 if(result?.structuredContent!==undefined){const s=result.structuredContent;if(s?.structuredContent!==undefined)return s.structuredContent;return s;}
 for(const item of result?.content||[])if(item.type==='text'){try{return JSON.parse(item.text)}catch{}}
 return null;
}
async function exposed(result:any){const response=connectorResponse(result);const b:any=await response.json();if(b.status==='reauthentication_required')b.chatGPTSignInPath=googleSignInPath('/');return reply(b,response.status);}
async function snapshot(api:ReturnType<typeof connectorsForRequest>){
 const result=await api.invoke(CONNECTOR,'get_spreadsheet_range',{spreadsheet_id:workbookId(),sheet_name:"'Giao dịch'",range:'A1:J10001',value_render_option:'UNFORMATTED_VALUE'});
 if(result.status!=='success')return {error:await exposed(result)};
 const body=payload(result.result);const values=body?.values;
 if(!Array.isArray(values)||HEADER.some((h,i)=>values[0]?.[i]!==h))return {error:reply({status:'invalid_sheet',message:'Tiêu đề bảng tính đã thay đổi. Khôi phục 10 cột gốc trước khi tiếp tục.'},409)};
 if(values.length>=10001)return {error:reply({status:'capacity_reached',message:'Bảng đã đạt giới hạn 10.000 dòng. Hãy liên hệ để mở rộng trước khi tiếp tục.'},409)};
 const rows:any[]=[];const ids=new Set<string>();
 for(let i=1;i<values.length;i++){
  const r=values[i];if(!r.some((v:any)=>v!==''&&v!==null))continue;
  const date=typeof r[1]==='number'?new Date((r[1]-25569)*86400000).toISOString().slice(0,10):r[1];
  const t={id:r[0],date,type:r[2]==='Thu'?'income':r[2]==='Chi'?'expense':'invalid',category:r[3],amount:r[4],wallet:r[5],note:r[6]??''};
  if(!entry.safeParse(t).success||ids.has(t.id)||!['Đang dùng','Đã xóa'].includes(r[8]))return {error:reply({status:'invalid_sheet',message:`Dòng ${i+1} có dữ liệu thiếu, trùng mã hoặc sai định dạng. Hãy kiểm tra trong Google Sheets.`},409)};
  ids.add(t.id);rows.push({...t,updated:r[7]||'',deleted:r[8]==='Đã xóa',op:r[9]||'',row:i});
 }
 return {rows,result};
}
export async function GET(){
 try{const s=await snapshot(connectorsForRequest());if(s.error)return s.error;return reply({status:'success',result:s.result?.result,rows:s.rows?.filter(t=>!t.deleted),sheetUrl:'https://docs.google.com/spreadsheets/d/'+workbookId()+'/edit'});}catch{return reply({status:'upstream_error',message:'Không tải được Google Sheets. Hãy thử Làm mới.'},502)}
}
export async function POST(req:Request){
 if(req.headers.get('origin')!==new URL(req.url).origin)return reply({status:'forbidden',message:'Nguồn yêu cầu không hợp lệ.'},403);
 if(!await getGoogleUser())return reply({status:'reauthentication_required',message:'Đăng nhập Google để lưu vào Google Sheets.',chatGPTSignInPath:googleSignInPath('/')},401);
 let input:z.infer<typeof write>;try{const raw=await req.text();if(raw.length>4096)throw Error();input=write.parse(JSON.parse(raw));}catch{return reply({status:'invalid_request',message:'Giao dịch không hợp lệ.'},400)}
 try{
  const api=connectorsForRequest(),s=await snapshot(api);if(s.error)return s.error;
  const previous=s.rows!.find(t=>t.id===input.entry.id);
  if(previous?.op===input.op)return reply({status:'success',result:s.result?.result,entry:previous});
  if(input.action==='create'&&previous)return reply({status:'conflict',message:'Mã giao dịch đã tồn tại. Hãy Làm mới để kiểm tra.'},409);
  if(input.action!=='create'&&(!previous||previous.deleted||previous.updated!==input.base))return reply({status:'conflict',message:'Giao dịch đã thay đổi. Hãy Làm mới rồi mở lại giao dịch.'},409);
  const t=input.action==='delete'?previous:input.entry,updated=new Date().toISOString(),deleted=input.action==='delete';
  const values=[t.id,Date.parse(t.date)/86400000+25569,t.type==='income'?'Thu':'Chi',t.category,t.amount,t.wallet,t.note,updated,deleted?'Đã xóa':'Đang dùng',input.op].map((v,i)=>({userEnteredValue:typeof v==='number'?{numberValue:v}:{stringValue:v},userEnteredFormat:{textFormat:{fontFamily:'Arial',fontSize:11},...(i===1?{numberFormat:{type:'DATE',pattern:'dd/mm/yyyy'}}:i===4?{numberFormat:{type:'NUMBER',pattern:'#,##0'}}:{})}}));
  const rows=[{values}];
  const request=previous?{updateCells:{start:{sheetId:SHEET,rowIndex:previous.row,columnIndex:0},rows,fields:'userEnteredValue,userEnteredFormat'}}:{appendCells:{sheetId:SHEET,rows,fields:'userEnteredValue,userEnteredFormat'}};
  const result=await api.invoke(CONNECTOR,'batch_update_spreadsheet',{spreadsheet_id:workbookId(),requests:[request as unknown as Json],include_spreadsheet_in_response:false});
  if(result.status!=='success')return exposed(result);
  return reply({status:'success',result:result.result,entry:{...input.entry,updated,deleted,op:input.op}});
 }catch{return reply({status:'upstream_error',message:'Chưa xác nhận được việc lưu. Bấm Làm mới để kiểm tra trước khi thử lại.'},502)}
}
