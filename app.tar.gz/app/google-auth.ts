import {runtime} from '../lib/runtime';
export async function getGoogleUser(){const c=runtime.getStore();return c?{userId:c.sub,email:c.email}:null}
export const googleSignInPath=(_path='/')=>'/auth/google';
