export function savingsEstimate(principal,rate,start,end,basis=365){
 const days=Math.round((Date.parse(end+'T00:00:00Z')-Date.parse(start+'T00:00:00Z'))/86400000);
 if(!Number.isFinite(days)||days<=0||!Number.isFinite(principal)||principal<=0||!Number.isFinite(rate)||rate<0||![360,365].includes(basis))throw new Error('Thông tin tính lãi không hợp lệ.');
 const interest=Math.round(principal*rate/100*days/basis);
 return {days,interest,total:principal+interest};
}
export function maturityFromMonths(start,months){
 if(!/^\d{4}-\d{2}-\d{2}$/.test(start)||!Number.isInteger(months)||months<1||months>600)return '';
 const [y,m,d]=start.split('-').map(Number),date=new Date(Date.UTC(y,m-1+months,1));
 const last=new Date(Date.UTC(date.getUTCFullYear(),date.getUTCMonth()+1,0)).getUTCDate();
 date.setUTCDate(Math.min(d,last));return date.toISOString().slice(0,10);
}
export function investmentReturn(principal,value){return value===null?null:{gain:value-principal,percent:(value-principal)/principal*100};}
