(async()=>{
 const el=id=>document.getElementById(id),gate=el('accountGate'),message=el('accountMessage');
 const state=await fetch('/api/me',{cache:'no-store'}).then(r=>r.json()).catch(()=>null);
 if(!state){message.textContent='Không kết nối được máy chủ. Tải lại trang để thử lại.';return}
 if(!state.configured){message.textContent='App đang chờ quản trị viên cấu hình đăng nhập Google.';return}
 if(!state.user){message.textContent=new URLSearchParams(location.search).has('auth')?'Chưa đăng nhập thành công. Hãy thử lại và cho phép app tạo/mở sổ riêng.':'Dữ liệu thuộc Google Drive của bạn. App chỉ xin quyền với các tệp được tạo hoặc mở qua app.';el('googleLogin').hidden=false;return}
 const originalFetch=window.fetch.bind(window);
 window.fetch=(input,options={})=>{const url=new URL(typeof input==='string'?input:input.url,location.origin);if(url.origin===location.origin&&url.pathname.startsWith('/api/')){const headers=new Headers(options.headers);headers.set('X-Session-Key',state.user.sessionKey);options={...options,headers}}return originalFetch(input,options)};
 el('accountBar').hidden=false;el('accountEmail').textContent=state.user.email;
 el('disconnectForm').onsubmit=()=>confirm('Thu hồi quyền Google và xóa phiên đăng nhập của app? File trong Drive vẫn được giữ. Bạn có thể đăng nhập lại để mở sổ cũ.');
 async function enter(book){if(!/^[A-Za-z0-9_-]+$/.test(book))throw Error('Invalid book');const url='https://docs.google.com/spreadsheets/d/'+book+'/edit';el('bookLink').href=url;document.querySelectorAll('[data-workbook-link]').forEach(a=>a.href=url);
 gate.hidden=true;el('financeApp').hidden=false;
 for(const [src,module] of [['/app.js',false],['/debts.js',false],['/assets.js',true]])await new Promise((resolve,reject)=>{const s=document.createElement('script');s.src=src;if(module)s.type='module';s.onload=resolve;s.onerror=reject;document.body.append(s)});
 }
 if(state.user.book){try{await enter(state.user.book)}catch{message.textContent='Không tải được app. Tải lại trang.';gate.hidden=false}return}
 message.textContent='Đã đăng nhập: '+state.user.email;el('openWorkbook').hidden=false;el('createExplanation').hidden=false;
 el('openWorkbook').onclick=async()=>{el('openWorkbook').disabled=true;message.textContent='Đang tìm hoặc tạo sổ trong Drive của bạn…';try{const r=await(await fetch('/api/workbook',{method:'POST'})).json();if(r.status!=='success')throw Error(r.message||'Không mở được sổ');await enter(r.book)}catch(e){message.textContent=e.message}finally{el('openWorkbook').disabled=false}};
})();
