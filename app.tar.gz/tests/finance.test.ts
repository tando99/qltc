import {test} from 'node:test';
import assert from 'node:assert/strict';
import {runtime} from '../lib/runtime';
import {connectorsForRequest} from '../lib/connectors';
import * as tx from '../app/api/transactions/route';
import * as debts from '../app/api/debts/route';
import * as assets from '../app/api/assets/route';
import {tabs} from '../lib/workbook';
import {savingsEstimate,maturityFromMonths,investmentReturn} from '../public/asset-math.mjs';
test('create and read transaction, debt, saving and investment through separate account books',async()=>{
 const books=new Map<string,any[][][]>([['a',tabs.map(t=>[t.headers])],['b',tabs.map(t=>[t.headers])]]);
 function context(sub:string){return {sub,email:sub+'@example.test',book:sub,google:async(url:string,method='GET',body?:any)=>{
 assert.ok(url.includes('/spreadsheets/'+sub));const sheets=books.get(sub)!;
 if(method==='POST'){for(const r of body.requests){const op=r.appendCells??r.updateCells,sheet=op.sheetId??op.start.sheetId,values=op.rows[0].values.map((v:any)=>v.userEnteredValue.numberValue??v.userEnteredValue.stringValue);if(r.appendCells)sheets[sheet].push(values);else sheets[sheet][op.start.rowIndex]=values}return {}}
 const range=decodeURIComponent(url),index=tabs.findIndex(t=>range.includes("'"+t.title+"'!"));return {values:sheets[index]};
 }}}
 async function write(handler:any,body:any){const request=new Request('https://app.test/api',{method:'POST',headers:{origin:'https://app.test'},body:JSON.stringify(body)});return runtime.run(context('a'),async()=>{const r=await handler.POST(request);const b=await r.json();assert.equal(r.status,200,JSON.stringify(b));return b})}
 const id='1234567890123456',op='abcdefghijklmnop';
 await write(tx,{action:'create',op,entry:{id,type:'income',date:'2026-11-05',category:'Lương',amount:100000,wallet:'Ngân hàng',note:''}});
 await write(tx,{action:'create',op,entry:{id,type:'income',date:'2026-11-05',category:'Lương',amount:100000,wallet:'Ngân hàng',note:''}});assert.equal(books.get('a')![0].length,2);
 await write(debts,{action:'create',op,entry:{id,type:'lend',person:'An',amount:1000000,date:'2026-11-05',due:'2026-12-05',note:''}});
 await write(assets,{kind:'savings',action:'create',op,id,entry:{id,name:'Ngân hàng',principal:100000000,rate:6,start:'2026-01-01',end:'2027-01-01',basis:365,state:'Đang gửi',note:''}});
 await write(assets,{kind:'investments',action:'create',op,id,entry:{id,name:'Quỹ',category:'Quỹ',principal:1000000,start:'2026-01-01',value:1100000,valuedAt:'2026-11-01',note:''}});
 const debt=await runtime.run(context('a'),async()=>((await debts.GET()).json()));const d=debt.rows[0];
 await write(debts,{action:'repay',op:'secondoperation1',id,base:d.base,payment:{id:'payment123456789',amount:300000,date:'2026-11-06',note:''}});
 const repaid=await runtime.run(context('a'),async()=>((await debts.GET()).json()));assert.equal(repaid.rows[0].remaining,700000);
 for(const kind of ['savings','investments']){const r=await runtime.run(context('a'),async()=>((await assets.GET(new Request('https://app.test/api?kind='+kind))).json()));assert.equal(r.rows.length,1)}
 const empty=await runtime.run(context('b'),async()=>((await tx.GET()).json()));assert.equal(empty.rows.length,0);
 await assert.rejects(runtime.run(context('b'),()=>connectorsForRequest().invoke('google','get_spreadsheet_range',{spreadsheet_id:'a'})));
});
test('interest, month end, leap year, missing valuation and total loss',()=>{
 assert.equal(savingsEstimate(100000000,6,'2026-01-01','2027-01-01').total,106000000);
 assert.equal(maturityFromMonths('2024-01-31',1),'2024-02-29');
 assert.equal(savingsEstimate(10000,5,'2024-02-28','2024-03-01').days,2);
 assert.equal(investmentReturn(100,null),null);assert.equal(investmentReturn(100,0)!.gain,-100);
});
