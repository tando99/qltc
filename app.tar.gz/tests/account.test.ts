import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {createApp} from '../server';
import {random,hash,vault,Locks} from '../lib/security';
import {googleService} from '../lib/google';
import {openStore} from '../lib/store';
import {tabs} from '../lib/workbook';
test('two devices open the same account workbook; another account is isolated; logout is per device',async()=>{
 const dir=mkdtempSync(join(tmpdir(),'finance-')),key=Buffer.alloc(32,7).toString('base64');
 const {app,db}=createApp({APP_ORIGIN:'http://localhost:3000',DATABASE_PATH:join(dir,'db'),GOOGLE_CLIENT_ID:'fixture',GOOGLE_CLIENT_SECRET:'fixture',TOKEN_KEY:key});
 const server=app.listen(0,'127.0.0.1');await new Promise<void>(r=>server.once('listening',r));const base='http://127.0.0.1:'+(server.address() as any).port;
 try{for(const [sub,book] of [['alice','book-alice'],['bob','book-bob']])db.prepare('INSERT INTO users(sub,email,tokens,book,ready) VALUES(?,?,?,?,1)').run(sub,sub+'@example.test','fixture',book);
 const a=random(),b=random(),c=random();for(const [session,sub] of [[a,'alice'],[b,'alice'],[c,'bob']])db.prepare('INSERT INTO sessions VALUES(?,?,?)').run(hash(session),sub,Date.now()+60000);
 async function me(s:string){return (await fetch(base+'/api/me',{headers:{Cookie:'finance_dev='+s}})).json()}
 assert.equal((await me(a)).user.book,'book-alice');assert.equal((await me(b)).user.book,'book-alice');assert.equal((await me(c)).user.book,'book-bob');
 assert.equal((await fetch(base+'/api/transactions',{headers:{Cookie:'finance_dev='+c,'X-Session-Key':hash(a)}})).status,409);
 assert.equal((await fetch(base+'/api/transactions',{headers:{'oai-authenticated-user-id':'alice'}})).status,401);
 assert.equal((await fetch(base+'/api/workbook',{method:'POST',headers:{Cookie:'finance_dev='+a,Origin:'https://evil.test','X-Session-Key':hash(a)}})).status,403);
 await fetch(base+'/auth/logout',{method:'POST',redirect:'manual',headers:{Cookie:'finance_dev='+a,Origin:'http://localhost:3000'}});
 assert.equal((await me(a)).user,null);assert.equal((await me(b)).user.book,'book-alice');
 assert.equal((await fetch(base+'/auth/google/callback?state=wrong')).status,400);
 }finally{await new Promise<void>(r=>server.close(()=>r()));db.close();rmSync(dir,{recursive:true,force:true})}
});
test('recover existing Drive workbook without creating a second one',async()=>{
 const dir=mkdtempSync(join(tmpdir(),'recover-')),db=openStore(join(dir,'db'));const g=googleService({clientId:'stable-client',clientSecret:'fixture',origin:'http://localhost:3000',tokenKey:Buffer.alloc(32,8).toString('base64')},db);
 db.prepare('INSERT INTO users(sub,email,tokens) VALUES(?,?,?)').run('alice','a@example.test','fixture');let posts=0;
 const result=await g.ensureBook('alice',async(url,method='GET')=>{if(method==='POST'){posts++;throw Error('Must not create')}
 if(url.includes('/drive/'))return {files:[{id:'existing-book'}]};
 if(url.includes('?fields=sheets.properties'))return {sheets:tabs.map(t=>({properties:{sheetId:t.id,title:t.title}}))};
 const decoded=decodeURIComponent(url),tab=tabs.find(t=>decoded.includes("'"+t.title+"'!"));return {values:[tab!.headers]};
 });
 assert.equal(result,'existing-book');assert.equal(posts,0);assert.equal((db.prepare('SELECT ready FROM users WHERE sub=?').get('alice') as any).ready,1);
 db.close();rmSync(dir,{recursive:true,force:true});
});
test('uncertain create is not replayed; encryption cannot be reused for another account',async()=>{
 const dir=mkdtempSync(join(tmpdir(),'uncertain-')),db=openStore(join(dir,'db'));const g=googleService({clientId:'fixture',clientSecret:'fixture',origin:'http://localhost:3000',tokenKey:Buffer.alloc(32,3).toString('base64')},db);
 db.prepare('INSERT INTO users(sub,email,tokens,creating) VALUES(?,?,?,1)').run('alice','a@example.test','fixture');
 let posts=0;await assert.rejects(g.ensureBook('alice',async(_url,method)=>{if(method==='POST')posts++;return {files:[]}}));assert.equal(posts,0);
 const v=vault(Buffer.alloc(32,2).toString('base64')),cipher=v.seal({refresh_token:'secret'},'alice');assert.equal(v.open(cipher,'alice').refresh_token,'secret');assert.throws(()=>v.open(cipher,'bob'));assert.ok(!cipher.includes('secret'));
 db.close();rmSync(dir,{recursive:true,force:true});
});
test('same account writes serialize, different accounts do not share a lock',async()=>{const locks=new Locks(),events:string[]=[];await Promise.all([locks.run('a',async()=>{events.push('start');await new Promise(r=>setTimeout(r,10));events.push('end')}),locks.run('a',async()=>{events.push('next')})]);assert.deepEqual(events,['start','end','next'])});
