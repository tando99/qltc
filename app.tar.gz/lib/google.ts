import {OAuth2Client,CodeChallengeMethod} from 'google-auth-library';
import type {DatabaseSync} from 'node:sqlite';
import {vault,hash} from './security';
import {setupRequests,tabs} from './workbook';
export const scope='https://www.googleapis.com/auth/drive.file';
export function googleService(config:{clientId:string;clientSecret:string;origin:string;tokenKey:string},db:DatabaseSync){const box=vault(config.tokenKey);const client=()=>new OAuth2Client(config.clientId,config.clientSecret,config.origin+'/auth/google/callback');
 return {client,box,async authorization(state:string,nonce:string){const c=client(),pkce=await c.generateCodeVerifierAsync();return {verifier:pkce.codeVerifier,url:c.generateAuthUrl({scope:['openid','email',scope],access_type:'offline',prompt:'consent select_account',state,nonce,code_challenge:pkce.codeChallenge,code_challenge_method:CodeChallengeMethod.S256})}},
 async userClient(sub:string){const row=db.prepare('SELECT tokens FROM users WHERE sub=?').get(sub) as any;if(!row)throw Error('Not signed in');const c=client();c.setCredentials(box.open(row.tokens,sub));c.on('tokens',tokens=>{const saved=db.prepare('SELECT tokens FROM users WHERE sub=?').get(sub) as any;if(!saved)return;db.prepare('UPDATE users SET tokens=? WHERE sub=?').run(box.seal({...box.open(saved.tokens,sub),...tokens},sub),sub)});return c},
 async ensureBook(sub:string,request:(url:string,method?:string,data?:any)=>Promise<any>){let row=db.prepare('SELECT * FROM users WHERE sub=?').get(sub) as any;const marker=hash(config.clientId+':'+sub);const base='https://www.googleapis.com/drive/v3/files';
 if(!row.book){const q="trashed=false and mimeType='application/vnd.google-apps.spreadsheet' and 'me' in owners and appProperties has { key='financeOwner' and value='"+marker+"' }";const found=await request(base+'?fields=files(id),nextPageToken&pageSize=100&q='+encodeURIComponent(q));
 if(found.nextPageToken||found.files?.length>1)throw Error('Có nhiều sổ khớp tài khoản. Cần kiểm tra trước khi tiếp tục.');
 if(found.files?.length===1){db.prepare('UPDATE users SET book=? WHERE sub=?').run(found.files[0].id,sub)}else{
 if(row.creating)throw Error('Lần tạo trước chưa được xác nhận. Kiểm tra Drive và thử lại sau; app không tự tạo sổ trùng.');
 db.prepare('UPDATE users SET creating=1 WHERE sub=?').run(sub);
 const file=await request(base+'?fields=id','POST',{name:'Sổ thu chi cá nhân',mimeType:'application/vnd.google-apps.spreadsheet',appProperties:{financeOwner:marker}});
 db.prepare('UPDATE users SET book=? WHERE sub=?').run(file.id,sub);
 }}
 row=db.prepare('SELECT * FROM users WHERE sub=?').get(sub) as any;
 if(!row.ready){const meta=await request('https://sheets.googleapis.com/v4/spreadsheets/'+encodeURIComponent(row.book)+'?fields=sheets.properties');
 let complete=true;for(const t of tabs){if(!meta.sheets?.some((s:any)=>s.properties.sheetId===t.id&&s.properties.title===t.title)){complete=false;break}const end=String.fromCharCode(64+t.headers.length);const h=await request('https://sheets.googleapis.com/v4/spreadsheets/'+row.book+'/values/'+encodeURIComponent("'"+t.title+"'!A1:"+end+'1'));if(t.headers.some((x,i)=>h.values?.[0]?.[i]!==x)){complete=false;break}}
 if(!complete){for(const sheet of meta.sheets||[]){const contents=await request('https://sheets.googleapis.com/v4/spreadsheets/'+row.book+'/values/'+encodeURIComponent("'"+sheet.properties.title.replaceAll("'","''")+"'"));if(contents.values?.length)throw Error('Sổ chưa đúng cấu trúc nhưng đã có dữ liệu. App không ghi đè dữ liệu đó.');}await request('https://sheets.googleapis.com/v4/spreadsheets/'+row.book+':batchUpdate','POST',{requests:setupRequests(meta.sheets||[])})}
 db.prepare('UPDATE users SET ready=1,creating=0 WHERE sub=?').run(sub);
 }
 return row.book as string;
 }}
}
