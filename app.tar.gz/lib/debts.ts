import {z} from 'zod';
export const debtHeaders=['Mã khoản vay','Loại','Người liên quan','Số tiền gốc (VND)','Ngày vay','Hạn trả','Ghi chú','Đã trả (VND)','Còn lại (VND)','Lịch sử trả nợ','Cập nhật','Trạng thái','Mã thao tác'];
export const identifier=z.string().regex(/^[a-zA-Z0-9-]{16,64}$/);
export const date=z.string().regex(/^\d{4}-\d{2}-\d{2}$/).refine(s=>{const d=new Date(s);return !isNaN(+d)&&d.toISOString().slice(0,10)===s;});
export const amount=z.number().int().positive().max(999999999999);
export const debtInput=z.object({id:identifier,type:z.enum(['borrow','lend']),person:z.string().trim().min(1).max(100),amount,date,due:z.union([date,z.literal('')]),note:z.string().max(1000)}).strict().refine(d=>!d.due||d.due>=d.date,{message:'Hạn trả không được trước ngày vay.'});
export const paymentInput=z.object({id:identifier,amount,date,note:z.string().max(300)}).strict();
export type DebtInput=z.infer<typeof debtInput>;
export type Payment=z.infer<typeof paymentInput>;
export function paidTotal(payments:Payment[]){return payments.reduce((sum,p)=>sum+p.amount,0);}
export function checkPayment(debt:DebtInput,payments:Payment[],payment:Payment){
 if(payment.date<debt.date)throw new Error('Ngày trả không được trước ngày vay.');
 if(payment.amount>debt.amount-paidTotal(payments))throw new Error('Số tiền trả vượt quá số còn nợ.');
 if(payments.length>=100)throw new Error('Khoản vay đã đạt giới hạn 100 lần trả.');
}
export function debtState(debt:DebtInput,payments:Payment[],today:string){const remaining=debt.amount-paidTotal(payments);return remaining===0?'Đã tất toán':debt.due&&debt.due<today?'Quá hạn':payments.length?'Trả một phần':'Chưa trả';}
export const serialDate=(s:string)=>s?Date.parse(s)/86400000+25569:'';
export const readDate=(v:unknown)=>typeof v==='number'?new Date((v-25569)*86400000).toISOString().slice(0,10):v;
