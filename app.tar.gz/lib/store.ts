import {DatabaseSync} from 'node:sqlite';
import {mkdirSync,chmodSync} from 'node:fs';
import {dirname} from 'node:path';
export function openStore(path:string){mkdirSync(dirname(path),{recursive:true,mode:0o700});const db=new DatabaseSync(path);chmodSync(path,0o600);
 db.exec('PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000; CREATE TABLE IF NOT EXISTS users(sub TEXT PRIMARY KEY,email TEXT NOT NULL,tokens TEXT NOT NULL,book TEXT,creating INTEGER NOT NULL DEFAULT 0,ready INTEGER NOT NULL DEFAULT 0); CREATE TABLE IF NOT EXISTS sessions(id TEXT PRIMARY KEY,sub TEXT NOT NULL,expires INTEGER NOT NULL); CREATE TABLE IF NOT EXISTS oauth(state TEXT PRIMARY KEY,nonce TEXT NOT NULL,verifier TEXT NOT NULL,browser TEXT NOT NULL,expires INTEGER NOT NULL);');return db}
