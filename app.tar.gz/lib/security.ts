import {randomBytes,createHash,createCipheriv,createDecipheriv,timingSafeEqual} from 'node:crypto';
export const random=()=>randomBytes(32).toString('base64url');
export const hash=(s:string)=>createHash('sha256').update(s).digest('hex');
export function same(a:string,b:string){const x=Buffer.from(a),y=Buffer.from(b);return x.length===y.length&&timingSafeEqual(x,y)}
export function vault(secret:string){if(Buffer.from(secret,'base64').length!==32)throw Error('TOKEN_KEY must be 32 random bytes encoded as base64');const key=Buffer.from(secret,'base64');return {
 seal(value:unknown,subject:string){const iv=randomBytes(12),cipher=createCipheriv('aes-256-gcm',key,iv);cipher.setAAD(Buffer.from(subject));const body=Buffer.concat([cipher.update(JSON.stringify(value)),cipher.final()]);return Buffer.concat([iv,cipher.getAuthTag(),body]).toString('base64')},
 open(value:string,subject:string){const b=Buffer.from(value,'base64'),decipher=createDecipheriv('aes-256-gcm',key,b.subarray(0,12));decipher.setAAD(Buffer.from(subject));decipher.setAuthTag(b.subarray(12,28));return JSON.parse(Buffer.concat([decipher.update(b.subarray(28)),decipher.final()]).toString())}
}}
export class Locks{private locks=new Map<string,Promise<void>>();async run<T>(key:string,fn:()=>Promise<T>):Promise<T>{const previous=this.locks.get(key)||Promise.resolve();let release!:()=>void;const next=new Promise<void>(r=>release=r);this.locks.set(key,next);await previous;try{return await fn()}finally{release();if(this.locks.get(key)===next)this.locks.delete(key)}}}
