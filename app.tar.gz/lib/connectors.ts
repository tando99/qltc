import {current} from './runtime';
export type Json=any;
export function connectorsForRequest(){const c=current();return {invoke:async(_connector:string,action:string,args:any)=>{
 if(!c.book||args.spreadsheet_id!==c.book)throw Error('Workbook isolation violation');
 try{let data;if(action==='get_spreadsheet_range'){data=await c.google('https://sheets.googleapis.com/v4/spreadsheets/'+encodeURIComponent(c.book)+'/values/'+encodeURIComponent(args.sheet_name+'!'+args.range)+'?valueRenderOption=UNFORMATTED_VALUE')}
 else if(action==='batch_update_spreadsheet'){data=await c.google('https://sheets.googleapis.com/v4/spreadsheets/'+encodeURIComponent(c.book)+':batchUpdate','POST',{requests:args.requests})}
 else throw Error('Unsupported operation');return {status:'success',result:{structuredContent:data}};
 }catch(e:any){const code=e.response?.status??e.status;return {status:code===401?'reauthentication_required':code===429?'rate_limited':'upstream_error',message:code===401?'Phiên Google hết hạn. Đăng nhập lại.':code===403?'Google chưa cấp đủ quyền. Đăng nhập lại và cho phép truy cập sổ.':code===404?'Không tìm thấy sổ. Kiểm tra Thùng rác trong Drive.':'Chưa xác nhận được thao tác. Làm mới để kiểm tra trước khi gửi lại.',...(code===429?{retryAfterMs:60000}:{})}}
}}}
