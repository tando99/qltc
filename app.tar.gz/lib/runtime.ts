import {AsyncLocalStorage} from 'node:async_hooks';
export type Runtime={sub:string,email:string,book:string,google:(url:string,method?:string,data?:unknown)=>Promise<any>};
export const runtime=new AsyncLocalStorage<Runtime>();
export function current(){const c=runtime.getStore();if(!c)throw Error('Authentication required');return c}
export const workbookId=()=>current().book;
