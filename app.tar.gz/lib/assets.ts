import {z} from 'zod';
import {identifier,date,amount} from './debts';
import {savingsEstimate,investmentReturn} from '../public/asset-math.mjs';
export const assetKind=z.enum(['savings','investments']);
export type Kind=z.infer<typeof assetKind>;
const note=z.string().max(1000),name=z.string().trim().min(1).max(100);
export const savingInput=z.object({id:identifier,name,principal:amount,rate:z.number().min(0).max(100),start:date,end:date,basis:z.union([z.literal(365),z.literal(360)]),state:z.enum(['Đang gửi','Đã nhận']),note}).strict().refine(d=>d.end>d.start,{message:'Ngày nhận phải sau ngày gửi.'});
export const investmentInput=z.object({id:identifier,name,category:name,principal:amount,start:date,value:z.number().int().min(0).max(999999999999).nullable(),valuedAt:z.union([date,z.literal('')]),note}).strict().refine(d=>d.value===null?d.valuedAt==='':!!d.valuedAt&&d.valuedAt>=d.start,{message:'Giá trị và ngày định giá phải được nhập cùng nhau, không trước ngày đầu tư.'});
export const configs={
 savings:{title:'Tiết kiệm',sheet:2,headers:['Mã khoản','Ngân hàng','Tiền gửi (VND)','Lãi suất (%/năm)','Ngày gửi','Ngày nhận dự kiến','Cơ sở ngày/năm','Trạng thái khoản','Ghi chú','Số ngày gửi','Lãi dự kiến (VND)','Cuối hạn dự kiến (VND)','Cập nhật','Trạng thái dòng','Mã thao tác'],keys:['id','name','principal','rate','start','end','basis','state','note'],dates:[4,5],numbers:[2,3,6,9,10,11]},
 investments:{title:'Đầu tư',sheet:3,headers:['Mã khoản','Tên khoản đầu tư','Hạng mục','Vốn đầu tư (VND)','Ngày đầu tư','Giá trị hiện tại (VND)','Ngày định giá','Ghi chú','Lãi/lỗ (VND)','Cập nhật','Trạng thái dòng','Mã thao tác'],keys:['id','name','category','principal','start','value','valuedAt','note'],dates:[4,6],numbers:[3,5,8]}
};
export function parseAsset(kind:Kind,input:unknown){return kind==='savings'?savingInput.parse(input):investmentInput.parse(input)}
export function calculated(kind:Kind,entry:any){return kind==='savings'?savingsEstimate(entry.principal,entry.rate,entry.start,entry.end,entry.basis):investmentReturn(entry.principal,entry.value)}
